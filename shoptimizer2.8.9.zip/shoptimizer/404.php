<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package shoptimizer
 */

if (!defined('ABSPATH')) exit;
get_header(); ?>

<?php shoptimizer_404_template(); ?>

<?php get_footer();
